/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Point {
  x: number;
  y: number;
}

export type Direction = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT';

export type GameState = 'MENU' | 'PLAYING' | 'PAUSED' | 'GAMEOVER' | 'MAZE_SELECT' | 'HELP';

export interface HighScore {
  score: number;
  date: string;
  maze: string;
  speed: string;
}

export interface MazeConfig {
  id: string;
  name: string;
  description: string;
  walls: Point[]; // Coordinates of walls
}

export interface SpeedConfig {
  level: number;
  name: string;
  millis: number;
}
