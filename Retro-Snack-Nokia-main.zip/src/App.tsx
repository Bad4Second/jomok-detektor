/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import NokiaPhone from './components/NokiaPhone';
import { Gamepad2, Heart, Shield } from 'lucide-react';

export default function App() {
  return (
    <div className="min-h-screen bg-gray-100 text-gray-900 flex flex-col justify-between">
      
      {/* HEADER SECTION - Elegant display typography with spacious padding */}
      <header className="w-full max-w-7xl mx-auto px-6 py-8 md:py-10 flex flex-col sm:flex-row items-center justify-between border-b border-gray-200/80 gap-4">
        <div className="flex flex-col items-center sm:items-start text-center sm:text-left">
          <h1 className="text-3xl sm:text-4xl font-extralight tracking-tight text-gray-900 uppercase">
            SNAKE CLASSIC
          </h1>
          <p className="text-[11px] text-gray-500 uppercase tracking-[0.25em] font-semibold mt-1">
            Minimalist Retro Gaming
          </p>
        </div>

        <div className="flex items-center gap-4 text-xs text-gray-500">
          <span className="flex items-center gap-1.5 px-3 py-1 bg-white border border-gray-200 rounded-full shadow-xs">
            <Shield className="w-3.5 h-3.5 text-green-600" />
            <span className="font-medium text-[11px]">Nokia 3310 Emulation Safe</span>
          </span>
        </div>
      </header>

      {/* CORE CONTENT: Centers the interactive phone mockup elegantly */}
      <main className="flex-1 flex items-center justify-center py-8 md:py-12">
        <div className="w-full max-w-7xl mx-auto px-4 flex flex-col items-center">
          
          <div className="text-center mb-8 max-w-lg hidden">
            <h2 className="text-2xl sm:text-3xl font-sans font-bold tracking-tight text-gray-900 mb-2">
              Game Snake Jadul
            </h2>
          </div>

          {/* Symmetrical Phone Component Wrapper */}
          <NokiaPhone />

        </div>
      </main>

      {/* FOOTER - Authentic simple human credentials & instructions */}
      <footer className="w-full border-t border-gray-200/80 bg-white/70 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-6 py-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-gray-500">
          <div className="text-center sm:text-left">
            &copy; {new Date().getFullYear()} Nokia Retro Snake. Dibuat dengan presisi untuk mengenang era HP monokrom.
          </div>
          
          <div className="flex items-center gap-1">
            <span>Didesain dengan presisi dan dimainkan pada browser Anda</span>
            <Heart className="w-3.5 h-3.5 text-red-500 fill-red-500 animate-pulse ml-0.5" />
          </div>
        </div>
      </footer>

    </div>
  );
}
