/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { GameState, Point, Direction, HighScore, MazeConfig, SpeedConfig } from '../types';
import { COLS, ROWS, MAZES } from '../mazes';
import { audio } from '../audio';
import { Play, Pause, RotateCcw, Volume2, VolumeX, List, HelpCircle, Trophy, ArrowRight, BookOpen, Settings } from 'lucide-react';

const SPEED_CONFIGS: SpeedConfig[] = [
  { level: 1, name: 'Lambat', millis: 280 },
  { level: 2, name: 'Sedang', millis: 190 },
  { level: 3, name: 'Cepat', millis: 120 },
  { level: 4, name: 'Ekstrim', millis: 75 }
];

interface GameScreenProps {
  onDirectionButtonPress?: (dir: Direction) => void;
  // External triggers to control direction from physical nokia buttons
  externalDirectionTrigger?: { dir: Direction | 'SELECT' | 'BACK'; timestamp: number } | null;
}

export default function GameScreen({ externalDirectionTrigger }: GameScreenProps) {
  // Game state
  const [gameState, setGameState] = useState<GameState>('MENU');
  const [snake, setSnake] = useState<Point[]>([]);
  const [direction, setDirection] = useState<Direction>('RIGHT');
  const [food, setFood] = useState<Point>({ x: 18, y: 8 });
  const [bonusFood, setBonusFood] = useState<Point | null>(null);
  const [bonusTimer, setBonusTimer] = useState<number>(0); // countdown ticks
  const [score, setScore] = useState<number>(0);
  const [highScores, setHighScores] = useState<HighScore[]>([]);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  
  // Settings
  const [selectedMaze, setSelectedMaze] = useState<MazeConfig>(MAZES[1]); // Box Classic by default
  const [selectedSpeed, setSelectedSpeed] = useState<SpeedConfig>(SPEED_CONFIGS[1]); // Sedang (120ms)
  const [menuIndex, setMenuIndex] = useState<number>(0);
  const [selectedMazeMenuIndex, setSelectedMazeMenuIndex] = useState<number>(1);
  const [selectedSpeedMenuIndex, setSelectedSpeedMenuIndex] = useState<number>(1);

  // References for snake loop
  const snakeRef = useRef<Point[]>([]);
  const directionRef = useRef<Direction>('RIGHT');
  const directionQueueRef = useRef<Direction[]>([]);
  const foodRef = useRef<Point>({ x: 18, y: 8 });
  const bonusFoodRef = useRef<Point | null>(null);
  const nextTickRef = useRef<number>(0);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const requestRef = useRef<number | null>(null);

  const lastProcessedTriggerRef = useRef<number>(0);

  // Sync state with refs for loop access
  snakeRef.current = snake;
  directionRef.current = direction;
  foodRef.current = food;
  bonusFoodRef.current = bonusFood;

  // Load high scores and sound mute state from storage on mount
  useEffect(() => {
    setIsMuted(audio.getMuteState());

    const storedScores = localStorage.getItem('nokia_snake_highscores_v1');
    if (storedScores) {
      try {
        setHighScores(JSON.parse(storedScores));
      } catch (e) {
        console.error('Failed to parse stored high scores', e);
      }
    } else {
      // Default placeholder original high score
      const defaults = [
        { score: 350, date: '02/06/2026', maze: 'Kotak Klasik', speed: 'Cepat' },
        { score: 210, date: '01/06/2026', maze: 'Kotak Klasik', speed: 'Sedang' },
        { score: 120, date: '30/05/2026', maze: 'Tanpa Batas', speed: 'Sedang' }
      ];
      setHighScores(defaults);
      localStorage.setItem('nokia_snake_highscores_v1', JSON.stringify(defaults));
    }
  }, []);

  // Sync muted state
  const handleToggleMute = useCallback(() => {
    const muted = audio.toggleMute();
    setIsMuted(muted);
  }, []);

  // Initialize snake position
  const resetGame = useCallback(() => {
    const initialSnake: Point[] = [
      { x: 8, y: 8 },
      { x: 7, y: 8 },
      { x: 6, y: 8 },
    ];
    setSnake(initialSnake);
    snakeRef.current = initialSnake;
    setDirection('RIGHT');
    directionRef.current = 'RIGHT';
    directionQueueRef.current = [];
    setScore(0);
    setBonusFood(null);
    setBonusTimer(0);
    bonusFoodRef.current = null;

    // Spawn regular food
    spawnFood(initialSnake, selectedMaze);

    setGameState('PLAYING');
    audio.playClick();
  }, [selectedMaze]);

  // Check if a point collides with walls
  const isWallCollision = useCallback((pos: Point, maze: MazeConfig): boolean => {
    // 1. Check custom maze inside walls
    if (maze.id !== 'nowalls' && maze.id !== 'box') {
      const match = maze.walls.some(w => w.x === pos.x && w.y === pos.y);
      if (match) return true;
    }

    // 2. Check outer walls if in "Box" or other mazes
    if (maze.id !== 'nowalls') {
      if (pos.x < 1 || pos.x >= COLS - 1 || pos.y < 1 || pos.y >= ROWS - 1) {
        return true;
      }
    }

    return false;
  }, []);

  // Spawn food safely outside snake body, inside wall config, outside and other food
  const spawnFood = (currentSnake: Point[], currentMaze: MazeConfig, isBonus = false) => {
    let attempts = 0;
    while (attempts < 500) {
      const x = Math.floor(Math.random() * (COLS - 2)) + 1;
      const y = Math.floor(Math.random() * (ROWS - 2)) + 1;
      const candidate: Point = { x, y };

      // Make sure it doesn't collide with walls
      const hitWall = isWallCollision(candidate, currentMaze);
      // Make sure it doesn't collide with snake body
      const hitSnake = currentSnake.some(seg => seg.x === candidate.x && seg.y === candidate.y);

      if (!hitSnake && !hitWall) {
        if (isBonus) {
          setBonusFood(candidate);
          bonusFoodRef.current = candidate;
          setBonusTimer(25); // Moves / steps countdown limit
        } else {
          setFood(candidate);
          foodRef.current = candidate;
        }
        break;
      }
      attempts++;
    }
  };

  // Process game step tick
  const gameTick = useCallback(() => {
    if (gameState !== 'PLAYING') return;

    let nextDir = directionRef.current;
    if (directionQueueRef.current.length > 0) {
      nextDir = directionQueueRef.current.shift()!;
    }
    setDirection(nextDir);
    directionRef.current = nextDir;

    const head = snakeRef.current[0];
    if (!head) return;
    let newHead: Point = { ...head };

    // Move in direction
    switch (nextDir) {
      case 'UP': newHead.y -= 1; break;
      case 'DOWN': newHead.y += 1; break;
      case 'LEFT': newHead.x -= 1; break;
      case 'RIGHT': newHead.x += 1; break;
    }

    // Screen wrapping for No Walls boundary mode
    if (selectedMaze.id === 'nowalls') {
      if (newHead.x < 0) newHead.x = COLS - 1;
      if (newHead.x >= COLS) newHead.x = 0;
      if (newHead.y < 0) newHead.y = ROWS - 1;
      if (newHead.y >= ROWS) newHead.y = 0;
    }

    // Check collisions
    const hitWall = isWallCollision(newHead, selectedMaze);
    // Don't check head-to-tail collision if it's wrapping but check self eating
    const hitSelf = snakeRef.current.slice(0, -1).some(seg => seg.x === newHead.x && seg.y === newHead.y);

    if (hitWall || hitSelf) {
      // Crash and Game Over!
      audio.playDie();
      setGameState('GAMEOVER');
      
      // Update high scores
      handleGameOver(score);
      return;
    }

    // Check if snake eats Regular Food
    const eatsRegular = newHead.x === foodRef.current.x && newHead.y === foodRef.current.y;
    // Check if snake eats Bonus Insect Food
    const eatsBonus = bonusFoodRef.current && (newHead.x === bonusFoodRef.current.x && newHead.y === bonusFoodRef.current.y);

    const updatedSnake = [newHead, ...snakeRef.current];

    if (eatsRegular) {
      audio.playEat();
      const pointsScored = 10 * selectedSpeed.level;
      setScore(prev => prev + pointsScored);
      
      // Remove regular food and spawn new - pass final updated snake
      spawnFood(updatedSnake, selectedMaze, false);

      // Chance of spawning a bonus bug/insect (approx 25% on eating under standard snake)
      if (!bonusFoodRef.current && Math.random() < 0.25) {
        spawnFood(updatedSnake, selectedMaze, true);
      }
    } else if (eatsBonus) {
      audio.playEat();
      const bonusPoints = (15 + (bonusTimer * 2)) * selectedSpeed.level;
      setScore(prev => prev + bonusPoints);
      setBonusFood(null);
      bonusFoodRef.current = null;
      setBonusTimer(0);
    } else {
      // Pop the tail if no food eaten
      updatedSnake.pop();
    }

    // Handle bonus insect countdown timer
    if (bonusFoodRef.current) {
      setBonusTimer(prev => {
        const nextValue = prev - 1;
        if (nextValue <= 0) {
          bonusFoodRef.current = null;
          setBonusFood(null);
          return 0;
        }
        return nextValue;
      });
    }

    setSnake(updatedSnake);
    snakeRef.current = updatedSnake;
  }, [gameState, selectedMaze, selectedSpeed, isWallCollision, score, bonusTimer]);

  // Game over highscore management
  const handleGameOver = (finalScore: number) => {
    if (finalScore <= 0) return;

    const today = new Date();
    const formattedDate = `${String(today.getDate()).padStart(2, '0')}/${String(today.getMonth() + 1).padStart(2, '0')}/${today.getFullYear()}`;
    
    setHighScores(prevScores => {
      const isNewHighScore = prevScores.length === 0 || finalScore > prevScores[0].score;
      
      const newScoreObj: HighScore = {
        score: finalScore,
        date: formattedDate,
        maze: selectedMaze.name,
        speed: selectedSpeed.name
      };

      let nextScores = [...prevScores, newScoreObj];
      // Sort descending
      nextScores.sort((a, b) => b.score - a.score);
      // Keep top 5
      nextScores = nextScores.slice(0, 5);

      localStorage.setItem('nokia_snake_highscores_v1', JSON.stringify(nextScores));

      if (isNewHighScore) {
        setTimeout(() => {
          audio.playHighScore();
        }, 300);
      }

      return nextScores;
    });
  };

  // Keyboard navigation controller
  const navigateMenu = useCallback((dir: 'UP' | 'DOWN' | 'SELECT' | 'BACK') => {
    audio.playMenuNavigate();

    if (gameState === 'MENU') {
      if (dir === 'UP') {
        setMenuIndex(prev => (prev === 0 ? 4 : prev - 1));
      } else if (dir === 'DOWN') {
        setMenuIndex(prev => (prev === 4 ? 0 : prev + 1));
      } else if (dir === 'SELECT') {
        if (menuIndex === 0) {
          resetGame();
        } else if (menuIndex === 1) {
          setGameState('MAZE_SELECT');
        } else if (menuIndex === 2) {
          // Speed Selection Settings Inline
          setGameState('MENU'); // toggle inline or menu item
        } else if (menuIndex === 3) {
          setGameState('HELP');
        } else if (menuIndex === 4) {
          handleToggleMute();
        }
      }
    } else if (gameState === 'MAZE_SELECT') {
      if (dir === 'UP') {
        setSelectedMazeMenuIndex(prev => (prev === 0 ? MAZES.length - 1 : prev - 1));
      } else if (dir === 'DOWN') {
        setSelectedMazeMenuIndex(prev => (prev === MAZES.length - 1 ? 0 : prev + 1));
      } else if (dir === 'SELECT') {
        setSelectedMaze(MAZES[selectedMazeMenuIndex]);
        setGameState('MENU');
      } else if (dir === 'BACK') {
        setGameState('MENU');
      }
    } else if (gameState === 'HELP' || gameState === 'GAMEOVER') {
      if (dir === 'SELECT' || dir === 'BACK') {
        setGameState('MENU');
      }
    } else if (gameState === 'PAUSED') {
      if (dir === 'SELECT') {
        setGameState('PLAYING');
      } else if (dir === 'BACK') {
        setGameState('MENU');
      }
    }
  }, [gameState, menuIndex, selectedMazeMenuIndex, selectedSpeedMenuIndex, resetGame, handleToggleMute]);

  // Handle external phone navigation clicks
  const changeDirection = useCallback((newDir: Direction) => {
    const oppDir: Record<Direction, Direction> = {
      UP: 'DOWN',
      DOWN: 'UP',
      LEFT: 'RIGHT',
      RIGHT: 'LEFT'
    };

    const currentActualDir = directionRef.current;

    if (directionQueueRef.current.length === 0) {
      if (newDir !== oppDir[currentActualDir] && newDir !== currentActualDir) {
        directionQueueRef.current.push(newDir);
        audio.playMove();
      }
    } else {
      const lastPendingDir = directionQueueRef.current[directionQueueRef.current.length - 1];
      
      if (newDir === lastPendingDir) {
        return;
      }

      if (newDir === oppDir[lastPendingDir]) {
        // They tapped opposite of the last pending direction inside the queue.
        // We can replace the last pending directions if they changed their mind
        // and it is a valid turn relative to the previous layout stage.
        const previousDir = directionQueueRef.current.length > 1
          ? directionQueueRef.current[directionQueueRef.current.length - 2]
          : currentActualDir;

        if (newDir !== oppDir[previousDir] && newDir !== previousDir) {
          directionQueueRef.current[directionQueueRef.current.length - 1] = newDir;
          audio.playMove();
        }
      } else {
        if (directionQueueRef.current.length < 3) {
          directionQueueRef.current.push(newDir);
          audio.playMove();
        }
      }
    }
  }, []);

  // Map keyboard events
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Prevent browser grid scrolling for arrow keys, spacebar
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', ' ', 'Spacebar'].includes(e.key)) {
        e.preventDefault();
      }

      if (gameState === 'PLAYING') {
        switch (e.key) {
          // Arrow keys
          case 'ArrowUp': changeDirection('UP'); break;
          case 'ArrowDown': changeDirection('DOWN'); break;
          case 'ArrowLeft': changeDirection('LEFT'); break;
          case 'ArrowRight': changeDirection('RIGHT'); break;
          // WASD controls
          case 'w': case 'W': changeDirection('UP'); break;
          case 's': case 'S': changeDirection('DOWN'); break;
          case 'a': case 'A': changeDirection('LEFT'); break;
          case 'd': case 'D': changeDirection('RIGHT'); break;
          // Nokia Numeric Keys: 2=UP, 8=DOWN, 4=LEFT, 6=RIGHT
          case '2': changeDirection('UP'); break;
          case '8': changeDirection('DOWN'); break;
          case '4': changeDirection('LEFT'); break;
          case '6': changeDirection('RIGHT'); break;
          // Pause hooks
          case ' ':
          case 'Enter':
          case 'Escape':
          case '5':
            audio.playClick();
            setGameState('PAUSED');
            break;
        }
      } else {
        // UI Navigation modes
        switch (e.key) {
          case 'ArrowUp':
          case 'w':
          case 'W':
          case '2':
            navigateMenu('UP');
            break;
          case 'ArrowDown':
          case 's':
          case 'S':
          case '8':
            navigateMenu('DOWN');
            break;
          case 'Enter':
          case ' ':
          case '5':
            navigateMenu('SELECT');
            break;
          case 'Escape':
          case 'Backspace':
          case '0':
          case 'c':
          case 'C':
            navigateMenu('BACK');
            break;
          // Toggle speed from classic keys within menu
          case 'ArrowRight':
          case '6':
          case 'd':
          case 'D':
            if (gameState === 'MENU' && menuIndex === 2) {
              audio.playClick();
              setSelectedSpeed(prev => {
                const nextLevel = prev.level === 4 ? 1 : prev.level + 1;
                return SPEED_CONFIGS[nextLevel - 1];
              });
            }
            break;
          case 'ArrowLeft':
          case '4':
          case 'a':
          case 'A':
            if (gameState === 'MENU' && menuIndex === 2) {
              audio.playClick();
              setSelectedSpeed(prev => {
                const nextLevel = prev.level === 1 ? 4 : prev.level - 1;
                return SPEED_CONFIGS[nextLevel - 1];
              });
            }
            break;
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameState, changeDirection, navigateMenu, menuIndex]);

  // Hook up external physical phone body press trigger
  useEffect(() => {
    if (externalDirectionTrigger && externalDirectionTrigger.timestamp > lastProcessedTriggerRef.current) {
      lastProcessedTriggerRef.current = externalDirectionTrigger.timestamp;
      
      const { dir } = externalDirectionTrigger;
      
      if (gameState === 'PLAYING') {
        if (dir === 'SELECT' || dir === 'BACK') {
          audio.playClick();
          setGameState('PAUSED');
        } else {
          changeDirection(dir as Direction);
        }
      } else {
        // Translate physical D-pad clicks or keypad to menu nav
        if (dir === 'UP') {
          navigateMenu('UP');
        } else if (dir === 'DOWN') {
          navigateMenu('DOWN');
        } else if (dir === 'SELECT') {
          navigateMenu('SELECT');
        } else if (dir === 'BACK') {
          navigateMenu('BACK');
        } else if (dir === 'LEFT' || dir === 'RIGHT') {
          // If hovering speed menu, allow settings toggle horizontal
          if (gameState === 'MENU' && menuIndex === 2) {
            audio.playClick();
            setSelectedSpeed(prev => {
              const delta = dir === 'LEFT' ? -1 : 1;
              let nextLevel = prev.level + delta;
              if (nextLevel < 1) nextLevel = 4;
              if (nextLevel > 4) nextLevel = 1;
              return SPEED_CONFIGS[nextLevel - 1];
            });
          }
        }
      }
    }
  }, [externalDirectionTrigger, gameState, menuIndex, changeDirection, navigateMenu]);

  // Main high-precision animation frame timer rendering the state to canvas
  useEffect(() => {
    const loop = (timestamp: number) => {
      if (gameState === 'PLAYING') {
        if (timestamp >= nextTickRef.current) {
          gameTick();
          nextTickRef.current = timestamp + selectedSpeed.millis;
        }
      }
      drawScreen();
      requestRef.current = requestAnimationFrame(loop);
    };

    nextTickRef.current = performance.now() + selectedSpeed.millis;
    requestRef.current = requestAnimationFrame(loop);
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [
    gameState,
    gameTick,
    selectedSpeed,
    menuIndex,
    selectedMazeMenuIndex,
    selectedMaze,
    isMuted,
    score,
    highScores,
    bonusTimer
  ]);

  // Draw the entire LCD Screen pixel matrix
  const drawScreen = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // Clear with retro green-yellow screen color
    ctx.fillStyle = '#9ba37e'; // Minimalist sage LCD
    ctx.fillRect(0, 0, width, height);

    // Apply high-contrast black grid pixels texture
    // Outer Border
    ctx.lineWidth = 1.5;
    ctx.strokeStyle = '#2b3024';
    ctx.strokeRect(4, 4, width - 8, height - 8);

    // Grid size setup
    // Offset standard viewport area
    const gameAreaOffsetTop = 16;
    const gameAreaHeight = height - gameAreaOffsetTop - 6;
    const gameAreaWidth = width - 8;

    const cellW = (gameAreaWidth) / COLS;
    const cellH = (gameAreaHeight) / ROWS;

    // Draw status bar at the top (Nokia logo style, score, and icons)
    ctx.fillStyle = '#2b3024';
    ctx.font = 'bold 8px monospace, Courier';
    ctx.fillText(`🐍 SKORE: ${score}`, 8, 12);

    // Speed details at top right
    const muteIcon = isMuted ? '🔇' : '🔊';
    const speedAlias = `SPD:${selectedSpeed.level}`;
    const mapAlias = selectedMaze.id === 'nowalls' ? '⌾' : '⛶';
    ctx.fillText(`${mapAlias} ${speedAlias} ${muteIcon}`, width - 74, 12);

    // Divider line between header and board
    ctx.beginPath();
    ctx.moveTo(4, 15);
    ctx.lineTo(width - 4, 15);
    ctx.strokeStyle = '#2b3024';
    ctx.lineWidth = 0.75;
    ctx.stroke();

    // GAME RENDERER SCREEN VIEWS
    if (gameState === 'MENU') {
      renderMainMenu(ctx, width, height);
    } else if (gameState === 'MAZE_SELECT') {
      renderMazeSelector(ctx, width, height);
    } else if (gameState === 'HELP') {
      renderHelp(ctx, width, height);
    } else if (gameState === 'PAUSED') {
      // Draw grid in background then put a clean overlay
      drawPixelGridArea(ctx, cellW, cellH, gameAreaOffsetTop);
      renderPaused(ctx, width, height);
    } else if (gameState === 'GAMEOVER') {
      drawPixelGridArea(ctx, cellW, cellH, gameAreaOffsetTop);
      renderGameOver(ctx, width, height);
    } else if (gameState === 'PLAYING') {
      drawPixelGridArea(ctx, cellW, cellH, gameAreaOffsetTop);
    }
  };

  // Render the classic liquid-crystal pixel grid area for the elements
  const drawPixelGridArea = (
    ctx: CanvasRenderingContext2D,
    cellW: number,
    cellH: number,
    offsetTop: number
  ) => {
    // 1. Draw Maze Walls first
    ctx.fillStyle = '#2b3024'; // Deep charcoal-olive
    
    // Draw outer borders if box mode
    if (selectedMaze.id !== 'nowalls') {
      ctx.fillStyle = '#2b3024';
      // Left Wall
      ctx.fillRect(4 + 0.5, offsetTop + 0.5, cellW - 0.5, (ROWS * cellH) - 0.5);
      // Right Wall
      ctx.fillRect(4 + (COLS - 1) * cellW + 0.5, offsetTop + 0.5, cellW - 0.5, (ROWS * cellH) - 0.5);
      // Top Wall
      ctx.fillRect(4 + 0.5, offsetTop + 0.5, (COLS * cellW) - 0.5, cellH - 0.5);
      // Bottom Wall
      ctx.fillRect(4 + 0.5, offsetTop + (ROWS - 1) * cellH + 0.5, (COLS * cellW) - 0.5, cellH - 0.5);
    }

    // Custom maze inside walls
    if (selectedMaze.id !== 'nowalls' && selectedMaze.id !== 'box') {
      ctx.fillStyle = '#2b3024';
      selectedMaze.walls.forEach(w => {
        const drawX = 4 + (w.x * cellW);
        const drawY = offsetTop + (w.y * cellH);
        // Draw double thickness retro pixel squares
        ctx.fillRect(drawX + 0.5, drawY + 0.5, cellW - 1, cellH - 1);
        ctx.strokeRect(drawX + 1.5, drawY + 1.5, cellW - 3, cellH - 3);
      });
    }

    // 2. Draw Snake Segments
    snakeRef.current.forEach((seg, index) => {
      const drawX = 4 + (seg.x * cellW);
      const drawY = offsetTop + (seg.y * cellH);
      
      ctx.fillStyle = '#2b3024';
      ctx.fillRect(drawX + 0.5, drawY + 0.5, cellW - 1, cellH - 1);

      // Add unique pattern to head or alternate segments for retro style
      if (index === 0) {
        // Eyes of the head
        ctx.fillStyle = '#9ba37e';
        const eyeSize = 1.5;
        // Directional offset eyes
        if (directionRef.current === 'RIGHT' || directionRef.current === 'LEFT') {
          ctx.fillRect(drawX + cellW / 2 + (directionRef.current === 'RIGHT' ? 1.5 : -2.5), drawY + 2, eyeSize, eyeSize);
          ctx.fillRect(drawX + cellW / 2 + (directionRef.current === 'RIGHT' ? 1.5 : -2.5), drawY + cellH - 4.5, eyeSize, eyeSize);
        } else {
          ctx.fillRect(drawX + 2, drawY + cellH / 2 + (directionRef.current === 'DOWN' ? 1.5 : -2.5), eyeSize, eyeSize);
          ctx.fillRect(drawX + cellW - 4.5, drawY + cellH / 2 + (directionRef.current === 'DOWN' ? 1.5 : -2.5), eyeSize, eyeSize);
        }
      } else {
        // Small inner pixel empty to give distinct snake segment beads look
        ctx.fillStyle = '#9ba37e';
        ctx.fillRect(drawX + 2, drawY + 2, cellW - 4, cellH - 4);
        ctx.fillStyle = '#2b3024';
        ctx.fillRect(drawX + 3.5, drawY + 3.5, cellW - 7, cellH - 7);
      }
    });

    // 3. Draw regular pixel food (little square blocks with flashing central dot)
    const foodDrawX = 4 + (foodRef.current.x * cellW);
    const foodDrawY = offsetTop + (foodRef.current.y * cellH);
    ctx.fillStyle = '#2b3024';
    // Square with spikes around it or central retro cross
    ctx.fillRect(foodDrawX + 1.5, foodDrawY + 1.5, cellW - 3, cellH - 3);
    ctx.fillStyle = '#9ba37e';
    ctx.fillRect(foodDrawX + 3, foodDrawY + 3, cellW - 6, cellH - 6);

    // 4. Draw bonus insect / extra bug (blinks and moves! Or stays static with timer countdown)
    if (bonusFoodRef.current && bonusTimer > 0) {
      const bonusDrawX = 4 + (bonusFoodRef.current.x * cellW);
      const bonusDrawY = offsetTop + (bonusFoodRef.current.y * cellH);
      
      // Make it blink rapidly
      if (Math.floor(Date.now() / 150) % 2 === 0) {
        ctx.fillStyle = '#2b3024';
        // Fill full cross star icon layout
        ctx.fillRect(bonusDrawX + 0.5, bonusDrawY + 2, cellW - 1, cellH - 4);
        ctx.fillRect(bonusDrawX + 2, bonusDrawY + 0.5, cellW - 4, cellH - 1);
        ctx.fillStyle = '#9ba37e';
        ctx.fillRect(bonusDrawX + 2.5, bonusDrawY + 2.5, cellW - 5, cellH - 5);
      }

      // Render mini countdown bar above/under bug
      ctx.fillStyle = '#2b3024';
      const timerWidth = (cellW * 1.5) * (bonusTimer / 25);
      ctx.fillRect(bonusDrawX - 1, bonusDrawY - 3, timerWidth, 1);
    }
  };

  // Render the original classic Nokia list menus
  const renderMainMenu = (ctx: CanvasRenderingContext2D, w: number, h: number) => {
    // Elegant game logo pixelated title
    ctx.fillStyle = '#2b3024';
    ctx.font = 'bold 12px monospace, Courier';
    ctx.fillText('NOKIA SNAKE II', (w / 2) - 48, 32);

    // Mini design separator
    ctx.fillRect((w / 2) - 52, 36, 104, 1.5);

    // Options UI
    const menuItems = [
      '1. MULAI GAME',
      '2. PILIH LABIRIN',
      `3. KEPATAN: < ${selectedSpeed.name} >`,
      '4. CARA BERMAIN',
      `5. SUARA: ${isMuted ? 'MATI (MUTED)' : 'AKTIF (ON)'}`
    ];

    ctx.font = '9px monospace, Courier';
    menuItems.forEach((item, idx) => {
      const topOffset = 54 + (idx * 16);
      if (idx === menuIndex) {
        // Highlighted item with retro side arrows
        ctx.fillStyle = '#2b3024';
        ctx.fillRect(8, topOffset - 9, w - 16, 12);
        
        ctx.fillStyle = '#9ba37e'; // inverted color
        ctx.fillText(`▶ ${item}`, 12, topOffset);
      } else {
        ctx.fillStyle = '#2b3024';
        ctx.fillText(`  ${item}`, 12, topOffset);
      }
    });

    // Outer tiny disclaimer scroll info
    ctx.fillStyle = '#2b3024';
    ctx.font = 'xs monospace, Courier';
    ctx.fillText('Tekan 2/8 (↑/↓) - Enter (5)', w / 2 - 62, h - 8);
  };

  // Render selection screen for grid mazes
  const renderMazeSelector = (ctx: CanvasRenderingContext2D, w: number, h: number) => {
    ctx.fillStyle = '#2b3024';
    ctx.font = 'bold 10px monospace, Courier';
    ctx.fillText('PILIH LABIRIN:', 12, 28);

    // List mazes
    ctx.font = '9px monospace, Courier';
    MAZES.forEach((maze, idx) => {
      const isSelected = selectedMaze.id === maze.id;
      const isHovered = selectedMazeMenuIndex === idx;
      const topOffset = 42 + (idx * 13);

      if (isHovered) {
        ctx.fillStyle = '#2b3024';
        ctx.fillRect(8, topOffset - 9, w - 16, 11);
        ctx.fillStyle = '#9ba37e';
      } else {
        ctx.fillStyle = '#2b3024';
      }

      ctx.fillText(`${isSelected ? '●' : '○'} ${maze.name}`, 12, topOffset);
    });

    // Render detailed description of hovered maze
    const currentHoveredMaze = MAZES[selectedMazeMenuIndex];
    ctx.fillStyle = '#2b3024';
    ctx.font = '7.5px monospace, Courier';
    
    // Manual text wrap
    const descText = currentHoveredMaze.description;
    const line1 = descText.slice(0, 42);
    const line2 = descText.slice(42);

    ctx.fillText(`Info: ${line1}`, 12, h - 25);
    if (line2) ctx.fillText(`      ${line2}`, 12, h - 17);

    ctx.fillRect(8, h - 35, w - 16, 0.5);

    ctx.font = '7px monospace, Courier';
    ctx.fillText('Enter/5: Pilih  |  Escape: Batal', w / 2 - 58, h - 6);
  };

  // Help Instructions view
  const renderHelp = (ctx: CanvasRenderingContext2D, w: number, h: number) => {
    ctx.fillStyle = '#2b3024';
    ctx.font = 'bold 10px monospace, Courier';
    ctx.fillText('CARA BERMAIN (KONTROL)', 12, 28);

    ctx.font = '8px monospace, Courier';
    const rules = [
      '- Panah Keyboard (↑ ↓ ← →)',
      '- ATAU tombol WASD',
      '- ATAU Tombol Angka Nokia:',
      '  2=Atas, 8=Bawah, 4=Kiri, 6=Kanan',
      '- Hindari tabrakan tubuh & dinding!',
      '- Makan bug hitam & serangga bintang',
      '  untuk raih skor tertinggi!',
      '- Tekan Space atau 5 untuk Pause.'
    ];

    rules.forEach((line, idx) => {
      ctx.fillText(line, 12, 44 + (idx * 10));
    });

    ctx.fillRect(8, h - 22, w - 16, 0.5);
    ctx.fillText('Tekan Enter atau Escape untuk kembali', w / 2 - 76, h - 11);
  };

  // Paused Mode Popup overlay
  const renderPaused = (ctx: CanvasRenderingContext2D, w: number, h: number) => {
    // Screen darkness alpha overlay using alternating striped pattern lines
    ctx.strokeStyle = '#2b3024';
    ctx.lineWidth = 0.5;
    for (let y = 16; y < h - 4; y += 4) {
      ctx.beginPath();
      ctx.moveTo(4, y);
      ctx.lineTo(w - 4, y);
      ctx.stroke();
    }

    // Modal card
    ctx.fillStyle = '#9ba37e';
    ctx.fillRect(w / 2 - 50, h / 2 - 25, 100, 42);
    ctx.strokeStyle = '#2b3024';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(w / 2 - 50, h / 2 - 25, 100, 42);

    ctx.fillStyle = '#2b3024';
    ctx.font = 'bold 10.5px monospace, Courier';
    ctx.fillText('PERMAINAN REHAT', w / 2 - 43, h / 2 - 10);

    ctx.font = '8px monospace, Courier';
    ctx.fillText('Enter/5: Lanjut', w / 2 - 34, h / 2 + 5);
    ctx.fillText('Esc / C: Menu', w / 2 - 31, h / 2 + 13);
  };

  // Game over rendering and high scores visualization
  const renderGameOver = (ctx: CanvasRenderingContext2D, w: number, h: number) => {
    // Dark overlay mask
    ctx.fillStyle = 'rgba(43, 48, 36, 0.15)';
    ctx.fillRect(4, 16, w - 8, h - 22);

    // Inner prompt container
    ctx.fillStyle = '#9ba37e';
    ctx.fillRect(w / 2 - 80, 24, 160, 110);
    ctx.strokeStyle = '#2b3024';
    ctx.lineWidth = 1;
    ctx.strokeRect(w / 2 - 80, 24, 160, 110);

    ctx.fillStyle = '#2b3024';
    ctx.font = 'bold 11px monospace, Courier';
    ctx.fillText('ULAR TABRAK! MATI', w / 2 - 54, 38);

    ctx.font = 'bold 10px monospace, Courier';
    ctx.fillText(`SKOR ANDA: ${score}`, w / 2 - 38, 52);

    // High Scores list Header
    ctx.fillRect(w / 2 - 65, 58, 130, 0.75);
    ctx.font = '7.5px monospace, Courier';
    ctx.fillText('--- REKOR SKOR TERATAS ---', w / 2 - 58, 67);

    // Top 3 high scores listing
    const slicedScores = highScores.slice(0, 3);
    slicedScores.forEach((row, k) => {
      const text = `${k + 1}. ${row.score} PTS (${row.maze.slice(0, 5)}) - ${row.date.slice(0, 5)}`;
      ctx.fillText(text, w/2 - 68, 77 + (k * 9));
    });

    if (slicedScores.length === 0) {
      ctx.fillText('Belum ada skor tercatat.', w/2 - 45, 80);
    }

    ctx.fillRect(w / 2 - 65, 107, 130, 0.75);
    ctx.font = '8px monospace, Courier';
    ctx.fillText('Tekan Enter / 5: Main Lagi', w / 2 - 62, 118);
    ctx.fillText('Tekan Escape / C: Ke Menu', w / 2 - 58, 128);
  };

  return (
    <div className="flex flex-col items-center select-none">
      {/* Visual Canvas Display representation */}
      <div className="relative p-2.5 bg-[#8fa172] rounded-xl border-[5px] border-[#7a8a61] shadow-[inset_0_2px_8px_rgba(0,0,0,0.3),_0_10px_20px_-5px_rgba(0,0,0,0.15)] flex items-center justify-center">
        {/* Anti-glare glassy overlay */}
        <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/5 to-white/10 rounded pointer-events-none z-10" />
        
        <canvas
          id="nokia_screen_canvas"
          ref={canvasRef}
          width={240}
          height={160}
          className="block rounded bg-[#9ba37e] shadow-[inset_0_2px_8px_rgba(0,0,0,0.4)] cursor-crosshair scale-100 image-render-pixelated"
          style={{ imageRendering: 'pixelated' }}
        />
      </div>

      {/* Real-time Game State Info Badge (Humble, responsive design, no system telemetry) */}
      <div className="mt-4 text-center">
        <div className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-white border border-gray-200/90 shadow-xs rounded-full text-xs text-gray-600 font-medium tracking-wide">
          <BookOpen className="w-3.5 h-3.5 text-gray-500" />
          <span>Labirin: <strong className="text-gray-900 font-semibold">{selectedMaze.name}</strong></span>
          <span className="text-gray-300">|</span>
          <span>Speed: <strong className="text-gray-900 font-semibold">{selectedSpeed.name}</strong></span>
        </div>
      </div>
    </div>
  );
}
