/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import GameScreen from './GameScreen';
import { Direction } from '../types';
import { Play, Volume2, Keyboard, HelpCircle, CornerDownLeft, Sparkles } from 'lucide-react';

export default function NokiaPhone() {
  const [directionTrigger, setDirectionTrigger] = useState<{ dir: Direction | 'SELECT' | 'BACK'; timestamp: number } | null>(null);

  // Map physical button click events
  const handleKeyClick = (keyType: 'UP' | 'DOWN' | 'LEFT' | 'RIGHT' | 'SELECT' | 'BACK') => {
    setDirectionTrigger({ dir: keyType, timestamp: Date.now() });
  };

  return (
    <div className="w-full max-w-5xl mx-auto flex flex-col lg:flex-row items-center justify-center gap-8 py-4 px-2">
      
      {/* 1. PHYSICAL NOKIA 3310 CHASSIS BODY */}
      <div id="nokia-phone-body" className="relative w-[340px] bg-[#374151] rounded-[50px] p-6 pt-7 pb-10 shadow-[0_25px_50px_-12px_rgba(0,0,0,0.2),_inset_0_4px_12px_rgba(255,255,255,0.15),_inset_0_-8px_16px_rgba(0,0,0,0.5)] border-[8px] border-[#4b5563] flex flex-col items-center">
        
        {/* Subtle physical reflection strip */}
        <div className="absolute top-0 left-12 right-12 h-1.5 bg-white/10 rounded-b-full filter blur-xs" />

        {/* Brand name and Speaker grill bar */}
        <div className="w-full flex flex-col items-center mb-4">
          {/* Authentic horizontal speaker slots */}
          <div className="flex gap-2 mb-2">
            <span className="w-8 h-2 bg-[#1b2325] rounded-full shadow-inner" strokeWidth="1.5" />
            <span className="w-3 h-2 bg-[#1b2325] rounded-full shadow-inner" />
          </div>
          <h1 className="text-sm font-sans tracking-[0.25em] text-neutral-300 font-bold select-none drop-shadow-md">
            SNAKE CLASSIC
          </h1>
        </div>

        {/* SCREEN SECTION CONTAINER with high-contrast screen bezel and metallic borders */}
        <div className="relative w-full aspect-[4/3.1] bg-[#1e292b] rounded-2xl p-4 shadow-[0_8px_16px_rgba(0,0,0,0.4),_inset_0_2px_4px_rgba(255,255,255,0.05),_inset_0_-4px_8px_rgba(0,0,0,0.7)] border-2 border-[#2b3538] flex flex-col justify-center items-center overflow-hidden">
          {/* Symmetrical bezel bands */}
          <div className="absolute left-0 top-0 bottom-0 w-2.5 bg-gradient-to-r from-transparent to-[#ffffff]/5" />
          <div className="absolute right-0 top-0 bottom-0 w-2.5 bg-gradient-to-l from-transparent to-[#ffffff]/5" />
          
          {/* LCD Module Screen Component */}
          <GameScreen externalDirectionTrigger={directionTrigger} />
        </div>

        {/* 2. Tactile Physical 3D Buttons Control Mesh Layout */}
        <div className="w-full mt-6 px-2 flex flex-col gap-4 select-none">
          
          {/* NAV BAR ROW 1: (C button / Go back) - Accent Blue Pad - (Arrows) */}
          <div className="grid grid-cols-3 gap-1 items-center">
            
            {/* Soft menu Left Clear (C) button */}
            <button
              id="btn-soft-left"
              onClick={() => handleKeyClick('BACK')}
              className="h-10 w-16 bg-white hover:bg-neutral-50 text-neutral-800 rounded-bl-[15px] rounded-tr-[5px] rounded-br-[5px] shadow-[0_4px_0_#cbd5e1,_0_6px_8px_rgba(0,0,0,0.15)] hover:shadow-[0_2px_0_#cbd5e1,_0_3px_5px_rgba(0,0,0,0.1)] active:translate-y-1 transition-all cursor-pointer font-bold text-xs flex flex-col items-center justify-center border border-gray-200/50"
            >
              <span className="text-[10px] tracking-tight">KEMBALI</span>
              <span className="text-[9px] font-sans text-neutral-500 font-semibold">C / 0</span>
            </button>

            {/* Symmetrical Central UP Arrow Dial */}
            <div className="flex flex-col items-center">
              <button
                id="btn-control-up"
                onClick={() => handleKeyClick('UP')}
                className="h-10 w-16 bg-[#1f2937] hover:bg-[#374151] text-neutral-200 rounded-[10px] shadow-[0_4px_0_#111827,_0_6px_8px_rgba(0,0,0,0.3)] active:translate-y-1 transition-all flex items-center justify-center cursor-pointer border-t border-white/5"
              >
                <div className="w-3 h-3 border-l-4 border-b-4 border-white rotate-[135deg] pr-1 pb-1" />
              </button>
            </div>

            {/* Soft menu Right SELECT / ACCEPT link button */}
            <button
              id="btn-soft-right"
              onClick={() => handleKeyClick('SELECT')}
              className="h-10 w-16 bg-white hover:bg-neutral-50 text-neutral-800 rounded-br-[15px] rounded-tl-[5px] rounded-bl-[5px] shadow-[0_4px_0_#cbd5e1,_0_6px_8px_rgba(0,0,0,0.15)] hover:shadow-[0_2px_0_#cbd5e1,_0_3px_5px_rgba(0,0,0,0.1)] active:translate-y-1 transition-all cursor-pointer font-bold text-xs flex flex-col items-center justify-center border border-gray-200/50"
            >
              <span className="text-[10px] tracking-tight font-bold">MASUK</span>
              <span className="text-[9px] text-neutral-500 font-semibold" style={{ fontSize: '9px' }}>ENTER/5</span>
            </button>
          </div>

          {/* NAV BAR ROW 2: (LEFT / DOWN / RIGHT) D-pad buttons */}
          <div className="grid grid-cols-3 gap-1 items-center justify-items-center mb-2">
            <button
              id="btn-control-left"
              onClick={() => handleKeyClick('LEFT')}
              className="h-9 w-14 bg-[#1f2937] hover:bg-[#374151] text-neutral-200 rounded-l-[10px] shadow-[0_4px_0_#111827,_0_5px_7px_rgba(0,0,0,0.3)] active:translate-y-1 transition-all flex items-center justify-center cursor-pointer"
            >
              <div className="w-2.5 h-2.5 border-l-3 border-b-3 border-white rotate-45" />
            </button>

            <button
              id="btn-control-down"
              onClick={() => handleKeyClick('DOWN')}
              className="h-10 w-16 bg-[#1f2937] hover:bg-[#374151] text-neutral-200 rounded-[10px] shadow-[0_4px_0_#111827,_0_6px_8px_rgba(0,0,0,0.3)] active:translate-y-1 transition-all flex items-center justify-center cursor-pointer border-b border-neutral-950"
            >
              <div className="w-2.5 h-2.5 border-r-3 border-b-3 border-white rotate-45" />
            </button>

            <button
              id="btn-control-right"
              onClick={() => handleKeyClick('RIGHT')}
              className="h-9 w-14 bg-[#1f2937] hover:bg-[#374151] text-neutral-200 rounded-r-[10px] shadow-[0_4px_0_#111827,_0_5px_7px_rgba(0,0,0,0.3)] active:translate-y-1 transition-all flex items-center justify-center cursor-pointer"
            >
              <div className="w-2.5 h-2.5 border-r-3 border-t-3 border-white rotate-45" />
            </button>
          </div>

          {/* NUMERIC KEYPAD MODULE: Standard 12-key tactile retro grid */}
          <div id="keypad-grid" className="grid grid-cols-3 gap-y-3.5 gap-x-2 mt-2">
            
            {/* Key 1 */}
            <div className="flex flex-col items-center">
              <button className="h-10 w-18 bg-white hover:bg-neutral-50 text-neutral-800 rounded-full shadow-[0_3.5px_0_#d1d5db,_0_5px_7px_rgba(0,0,0,0.15)] hover:shadow-md active:translate-y-0.5 transition-all cursor-pointer flex flex-col items-center justify-center font-bold border border-neutral-200/50">
                <span className="text-sm font-bold leading-none">1</span>
                <span className="text-[7px] text-neutral-400 font-medium tracking-wide">o _ o</span>
              </button>
            </div>

            {/* Key 2 (UP) */}
            <div className="flex flex-col items-center">
              <button
                onClick={() => handleKeyClick('UP')}
                className="h-10 w-18 bg-white hover:bg-neutral-50 text-neutral-800 rounded-full shadow-[0_3.5px_0_#d1d5db,_0_5px_7px_rgba(0,0,0,0.15)] hover:shadow-md active:translate-y-0.5 transition-all cursor-pointer flex flex-col items-center justify-center font-bold relative group border border-neutral-200/50"
              >
                <div className="absolute top-1 text-[7px] opacity-65 text-emerald-700 group-hover:scale-110">▲</div>
                <span className="text-sm font-bold leading-none mt-1">2</span>
                <span className="text-[7px] text-neutral-400 font-medium">ABC</span>
              </button>
            </div>

            {/* Key 3 */}
            <div className="flex flex-col items-center">
              <button className="h-10 w-18 bg-white hover:bg-neutral-50 text-neutral-800 rounded-full shadow-[0_3.5px_0_#d1d5db,_0_5px_7px_rgba(0,0,0,0.15)] hover:shadow-md active:translate-y-0.5 transition-all cursor-pointer flex flex-col items-center justify-center font-bold border border-neutral-200/50">
                <span className="text-sm font-bold leading-none">3</span>
                <span className="text-[7px] text-neutral-400 font-medium">DEF</span>
              </button>
            </div>

            {/* Key 4 (LEFT) */}
            <div className="flex flex-col items-center">
              <button
                onClick={() => handleKeyClick('LEFT')}
                className="h-10 w-18 bg-white hover:bg-neutral-50 text-neutral-800 rounded-full shadow-[0_3.5px_0_#d1d5db,_0_5px_7px_rgba(0,0,0,0.15)] hover:shadow-md active:translate-y-0.5 transition-all cursor-pointer flex flex-col items-center justify-center font-bold relative group border border-neutral-200/50"
              >
                <div className="absolute left-2.5 text-[7px] opacity-65 text-emerald-700 group-hover:scale-110">◀</div>
                <span className="text-sm font-bold leading-none mt-0.5 ml-1">4</span>
                <span className="text-[7px] text-neutral-400 font-medium ml-1">GHI</span>
              </button>
            </div>

            {/* Key 5 (OK / ENTER) */}
            <div className="flex flex-col items-center">
              <button
                onClick={() => handleKeyClick('SELECT')}
                className="h-10 w-18 bg-white hover:bg-neutral-50 text-neutral-900 rounded-full shadow-[0_3.5px_0_#cbd5e1,_0_5px_7px_rgba(0,0,0,0.15)] hover:shadow-md active:translate-y-0.5 transition-color duration-150 cursor-pointer flex flex-col items-center justify-center font-extrabold border-[2px] border-emerald-600/30"
              >
                <span className="text-sm font-extrabold text-emerald-700">5</span>
                <span className="text-[7px] text-emerald-600 font-extrabold">OK</span>
              </button>
            </div>

            {/* Key 6 (RIGHT) */}
            <div className="flex flex-col items-center">
              <button
                onClick={() => handleKeyClick('RIGHT')}
                className="h-10 w-18 bg-white hover:bg-neutral-50 text-neutral-800 rounded-full shadow-[0_3.5px_0_#d1d5db,_0_5px_7px_rgba(0,0,0,0.15)] hover:shadow-md active:translate-y-0.5 transition-all cursor-pointer flex flex-col items-center justify-center font-bold relative group border border-neutral-200/50"
              >
                <div className="absolute right-2.5 text-[7px] opacity-65 text-emerald-700 group-hover:scale-110">▶</div>
                <span className="text-sm font-bold leading-none mt-0.5 mr-1">6</span>
                <span className="text-[7px] text-neutral-400 font-medium mr-1">MNO</span>
              </button>
            </div>

            {/* Key 7 */}
            <div className="flex flex-col items-center">
              <button className="h-10 w-18 bg-white hover:bg-neutral-50 text-neutral-800 rounded-full shadow-[0_3.5px_0_#d1d5db,_0_5px_7px_rgba(0,0,0,0.15)] hover:shadow-md active:translate-y-0.5 transition-all cursor-pointer flex flex-col items-center justify-center font-bold border border-neutral-200/50">
                <span className="text-sm font-bold leading-none">7</span>
                <span className="text-[7px] text-neutral-400 font-medium">PQRS</span>
              </button>
            </div>

            {/* Key 8 (DOWN) */}
            <div className="flex flex-col items-center">
              <button
                onClick={() => handleKeyClick('DOWN')}
                className="h-10 w-18 bg-white hover:bg-neutral-50 text-neutral-800 rounded-full shadow-[0_3.5px_0_#d1d5db,_0_5px_7px_rgba(0,0,0,0.15)] hover:shadow-md active:translate-y-0.5 transition-all cursor-pointer flex flex-col items-center justify-center font-bold relative group border border-neutral-200/50"
              >
                <span className="text-sm font-bold leading-none mb-1">8</span>
                <span className="text-[7px] text-neutral-400 font-medium">TUV</span>
                <div className="absolute bottom-1.5 text-[7px] opacity-65 text-emerald-700 group-hover:scale-110">▼</div>
              </button>
            </div>

            {/* Key 9 */}
            <div className="flex flex-col items-center">
              <button className="h-10 w-18 bg-white hover:bg-neutral-50 text-neutral-800 rounded-full shadow-[0_3.5px_0_#d1d5db,_0_5px_7px_rgba(0,0,0,0.15)] hover:shadow-md active:translate-y-0.5 transition-all cursor-pointer flex flex-col items-center justify-center font-bold border border-neutral-200/50">
                <span className="text-sm font-bold leading-none">9</span>
                <span className="text-[7px] text-neutral-400 font-medium">WXYZ</span>
              </button>
            </div>

            {/* Key * */}
            <div className="flex flex-col items-center">
              <button className="h-10 w-18 bg-white hover:bg-neutral-50 text-neutral-800 rounded-full shadow-[0_3.5px_0_#d1d5db,_0_5px_7px_rgba(0,0,0,0.15)] hover:shadow-md active:translate-y-0.5 transition-all cursor-pointer flex flex-col items-center justify-center font-bold border border-neutral-200/50">
                <span className="text-sm font-bold leading-none">*</span>
                <span className="text-[7px] text-neutral-400 font-medium">⚙ / +</span>
              </button>
            </div>

            {/* Key 0 */}
            <div className="flex flex-col items-center">
              <button
                onClick={() => handleKeyClick('BACK')}
                className="h-10 w-18 bg-white hover:bg-neutral-50 text-neutral-800 rounded-full shadow-[0_3.5px_0_#d1d5db,_0_5px_7px_rgba(0,0,0,0.15)] hover:shadow-md active:translate-y-0.5 transition-all cursor-pointer flex flex-col items-center justify-center font-bold border border-neutral-200/50"
              >
                <span className="text-sm font-bold leading-none">0</span>
                <span className="text-[7px] text-neutral-400 font-medium">└┘</span>
              </button>
            </div>

            {/* Key # */}
            <div className="flex flex-col items-center">
              <button className="h-10 w-18 bg-white hover:bg-neutral-50 text-neutral-800 rounded-full shadow-[0_3.5px_0_#d1d5db,_0_5px_7px_rgba(0,0,0,0.15)] hover:shadow-md active:translate-y-0.5 transition-all cursor-pointer flex flex-col items-center justify-center font-bold border border-neutral-200/50">
                <span className="text-sm font-bold leading-none">#</span>
                <span className="text-[7px] text-neutral-400 font-medium">⇧ / aA</span>
              </button>
            </div>

          </div>

        </div>
      </div>

      {/* 3. PHYSICAL KEYBOARD MINIMAL INSTRUCTIONS BOX PANEL CARD */}
      <div id="retro-instructions" className="flex-1 bg-white border border-gray-200 rounded-3xl p-6 text-gray-700 max-w-md shadow-lg shadow-gray-200/40 flex flex-col justify-between">
        <div className="space-y-5">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-[#8fa172]/15 rounded-xl border border-[#8fa172]/30">
              <Sparkles className="w-5 h-5 text-[#7a8a61]" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-gray-900 tracking-wide">Classic Snake Experience</h2>
              <p className="text-xs text-gray-400 uppercase tracking-wider font-semibold">Tampilan Minimalis &amp; Audio Retro</p>
            </div>
          </div>

          <p className="text-sm text-gray-500 leading-relaxed">
            Mainkan kembali game ular legendaris tahun 2000-an yang direka ulang secara sempurna dengan presisi pixel. Bermainlah menggunakan keyboard PC Anda atau klik tombol-tombol fisik HP di sebelah kiri!
          </p>

          <div className="space-y-4 pt-1.5">
            <h3 className="text-xs font-bold text-gray-800 uppercase tracking-wider flex items-center gap-2">
              <Keyboard className="w-4 h-4 text-gray-400" /> Kontrol Keyboard PC Anda
            </h3>
            
            <div className="grid grid-cols-2 gap-3 text-xs leading-5">
              <div className="bg-gray-50 p-2.5 rounded-lg border border-gray-100">
                <p className="font-semibold text-gray-800 flex items-center gap-1.5 justify-start">
                  <span className="inline-block bg-white border border-gray-200 rounded text-[10px] text-gray-800 shadow-xs px-1.5 py-0.5 font-bold font-mono">↑</span>
                  <span className="inline-block bg-white border border-gray-200 rounded text-[10px] text-gray-800 shadow-xs px-1.5 py-0.5 font-bold font-mono">↓</span>
                  <span className="inline-block bg-white border border-gray-200 rounded text-[10px] text-gray-800 shadow-xs px-1.5 py-0.5 font-bold font-mono">←</span>
                  <span className="inline-block bg-white border border-gray-200 rounded text-[10px] text-gray-800 shadow-xs px-1.5 py-0.5 font-bold font-mono">→</span>
                </p>
                <p className="text-[11px] text-gray-500 mt-1.5 font-light">Gunakan Tombol panah standar.</p>
              </div>

              <div className="bg-gray-50 p-2.5 rounded-lg border border-gray-100">
                <p className="font-semibold text-gray-800 flex items-center gap-1">
                  <span className="inline-block bg-white border border-gray-200 rounded text-[10px] text-gray-800 shadow-xs px-1.5 py-0.5 font-bold font-mono">W</span>
                  <span className="inline-block bg-white border border-gray-200 rounded text-[10px] text-gray-800 shadow-xs px-1.5 py-0.5 font-bold font-mono">A</span>
                  <span className="inline-block bg-white border border-gray-200 rounded text-[10px] text-gray-800 shadow-xs px-1.5 py-0.5 font-bold font-mono">S</span>
                  <span className="inline-block bg-white border border-gray-200 rounded text-[10px] text-gray-800 shadow-xs px-1.5 py-0.5 font-bold font-mono">D</span>
                </p>
                <p className="text-[11px] text-gray-500 mt-1.5 font-light">Gunakan tombol WASD.</p>
              </div>

              <div className="bg-gray-50 p-2.5 rounded-lg border border-gray-100">
                <p className="font-semibold text-gray-800 flex items-center gap-1">
                  <span className="inline-block bg-white border border-gray-200 rounded text-[10px] text-gray-800 shadow-xs px-1.5 py-0.5 font-bold font-mono">2</span>
                  <span className="inline-block bg-white border border-gray-200 rounded text-[10px] text-gray-800 shadow-xs px-1.5 py-0.5 font-bold font-mono">4</span>
                  <span className="inline-block bg-white border border-gray-200 rounded text-[10px] text-gray-800 shadow-xs px-1.5 py-0.5 font-bold font-mono">6</span>
                  <span className="inline-block bg-white border border-gray-200 rounded text-[10px] text-gray-800 shadow-xs px-1.5 py-0.5 font-bold font-mono">8</span>
                </p>
                <p className="text-[11px] text-gray-500 mt-1.5 font-light">Tombol angka HP klasik.</p>
              </div>

              <div className="bg-gray-50 p-2.5 rounded-lg border border-gray-100 flex flex-col justify-between">
                <p className="font-semibold text-gray-800 flex items-center gap-1">
                  <span className="inline-block bg-white border border-gray-200 rounded text-[10px] text-gray-800 shadow-xs px-1.5 py-0.5 font-bold font-mono">Enter</span>
                  <span className="text-gray-400 font-normal text-[10px]">atau</span>
                  <span className="inline-block bg-white border border-gray-200 rounded text-[10px] text-gray-800 shadow-xs px-1.5 py-0.5 font-bold font-mono">Spasi</span>
                </p>
                <p className="text-[11px] text-gray-500 mt-1.5 font-light">PILIH menu / Jeda (Pause).</p>
              </div>
            </div>
          </div>

          <div className="space-y-2 pt-3 border-t border-gray-100">
            <h4 className="text-xs font-bold text-gray-800 uppercase tracking-wider flex items-center gap-2">
              <CornerDownLeft className="w-3.5 h-3.5 text-gray-400" /> Tips Meraih Rekor:
            </h4>
            <ul className="text-xs text-gray-500 space-y-1.5 pl-4 list-disc list-outside font-light">
              <li>Pilih kecepatan yang lebih tinggi untuk melipatgandakan perolehan poin Anda!</li>
              <li>Tantang diri Anda dengan memilih salah satu di antara <strong className="text-gray-800 font-semibold">5 Jenis Labirin Dinding</strong> yang tersedia di menu.</li>
              <li>Dapatkan serangga bintang bonus berkedip ketika muncul. Serangga ini memiliki batas waktu countdown bar!</li>
            </ul>
          </div>
        </div>

        {/* Nostalgic footer note with absolutely zero larping ports */}
        <div className="mt-8 pt-4 border-t border-gray-100 text-center flex items-center justify-between">
          <div className="text-[10px] text-gray-400 font-medium">
            Simulasi Klasik Generasi 2000-an
          </div>
          <div className="flex items-center gap-1.5 text-xs text-gray-600 bg-gray-50 px-3 py-1.5 rounded-full border border-gray-100">
            <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping" />
            <span className="font-medium text-[11px]">Ready to Play</span>
          </div>
        </div>

      </div>

    </div>
  );
}
