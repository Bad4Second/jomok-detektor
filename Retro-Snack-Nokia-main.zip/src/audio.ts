/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

class RetroAudio {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;

  constructor() {
    // Lazy initialisation due to browser autoplacing/autoplay restrictions
    this.isMuted = localStorage.getItem('nokia_snake_muted') === 'true';
  }

  private initCtx(): AudioContext {
    if (!this.ctx) {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioCtxClass();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    localStorage.setItem('nokia_snake_muted', String(this.isMuted));
    // Play a tiny confirmation click if unmuting
    if (!this.isMuted) {
      setTimeout(() => this.playClick(), 50);
    }
    return this.isMuted;
  }

  public getMuteState(): boolean {
    return this.isMuted;
  }

  private playTone(freq: number, durationMs: number, type: OscillatorType = 'square', volumeValue: number = 0.08) {
    if (this.isMuted) return;
    try {
      const context = this.initCtx();
      const osc = context.createOscillator();
      const gainNode = context.createGain();

      osc.type = type; // 'square' is perfect for original retro Nokia sound
      osc.frequency.setValueAtTime(freq, context.currentTime);

      gainNode.gain.setValueAtTime(volumeValue, context.currentTime);
      // Nice sharp sound cutoff
      gainNode.gain.exponentialRampToValueAtTime(0.0001, context.currentTime + durationMs / 1000);

      osc.connect(gainNode);
      gainNode.connect(context.destination);

      osc.start();
      osc.stop(context.currentTime + durationMs / 1000);
    } catch (e) {
      // Audio context error fallback, fail silently if audio isn't supported or active
      console.warn("Audio failed to play", e);
    }
  }

  public playClick() {
    // Soft, rapid high beep for tactile feedback
    this.playTone(2000, 30, 'sine', 0.04);
  }

  public playMove() {
    this.playTone(600, 20, 'sine', 0.01);
  }

  public playEat() {
    // Classical rising arpeggio / quick double beep
    this.playTone(987.77, 80, 'square', 0.05); // B5
    setTimeout(() => {
      this.playTone(1318.51, 100, 'square', 0.05); // E6
    }, 70);
  }

  public playDie() {
    // Falling buzzer beep
    this.playTone(329.63, 150, 'square', 0.08); // E4
    setTimeout(() => {
      this.playTone(220.00, 250, 'square', 0.10); // A3
    }, 120);
  }

  public playMenuNavigate() {
    this.playTone(1046.50, 40, 'square', 0.03); // C6
  }

  public playHighScore() {
    // Beautiful positive Nokia style melody
    const notes = [659.25, 659.25, 0, 659.25, 0, 523.25, 659.25, 0, 783.99, 0, 392.00]; // Mario style short
    const timings = [70, 70, 70, 70, 70, 70, 70, 70, 70, 100, 200];
    let elapsed = 0;
    
    notes.forEach((freq, idx) => {
      if (freq > 0) {
        setTimeout(() => {
          this.playTone(freq, timings[idx], 'square', 0.06);
        }, elapsed);
      }
      elapsed += timings[idx] + 20;
    });
  }
}

export const audio = new RetroAudio();
