/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { MazeConfig, Point } from './types';

// Board size config
export const COLS = 26;
export const ROWS = 18;

// Helper to generate a line of points
function makeLine(xStart: number, yStart: number, xEnd: number, yEnd: number): Point[] {
  const points: Point[] = [];
  const minX = Math.min(xStart, xEnd);
  const maxX = Math.max(xStart, xEnd);
  const minY = Math.min(yStart, yEnd);
  const maxY = Math.max(yStart, yEnd);

  for (let x = minX; x <= maxX; x++) {
    for (let y = minY; y <= maxY; y++) {
      points.push({ x, y });
    }
  }
  return points;
}

export const MAZES: MazeConfig[] = [
  {
    id: 'nowalls',
    name: 'Tanpa Batas',
    description: 'Tembus dinding samping, hanya mati jika menabrak diri sendiri.',
    walls: []
  },
  {
    id: 'box',
    name: 'Kotak Klasik',
    description: 'Dinding luar padat. Jangan tabrak dinding tepi layar!',
    walls: [] // Box walls are dynamically checked or rendered based on flag in logic
  },
  {
    id: 'double_bar',
    name: 'Batang Ganda',
    description: 'Dua dinding vertikal di kiri & kanan tengah.',
    walls: [
      ...makeLine(7, 4, 7, 13),
      ...makeLine(18, 4, 18, 13)
    ]
  },
  {
    id: 'apart',
    name: 'Apartemen',
    description: 'Dinding penyekat horizontal di bagian atas & bawah.',
    walls: [
      ...makeLine(4, 5, 21, 5),
      ...makeLine(4, 12, 21, 12)
    ]
  },
  {
    id: 'spiral',
    name: 'Labirin Laba-laba',
    description: 'Struktur labirin melingkar di tengah layar.',
    walls: [
      ...makeLine(4, 3, 21, 3),
      ...makeLine(4, 14, 21, 14),
      ...makeLine(4, 4, 4, 7),
      ...makeLine(21, 10, 21, 13),
      ...makeLine(12, 7, 15, 7),
      ...makeLine(12, 10, 15, 10)
    ]
  }
];
